-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: j5a203.p.ssafy.io    Database: OnAir
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_user`
--

DROP TABLE IF EXISTS `accounts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user` (
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `id` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `google_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user`
--

LOCK TABLES `accounts_user` WRITE;
/*!40000 ALTER TABLE `accounts_user` DISABLE KEYS */;
INSERT INTO `accounts_user` VALUES ('pbkdf2_sha256$260000$Ol7UI3UBerMpvVmo3N9Nrq$tka0PQI9K/xHwujCcTMSUUWAdkqTC8MOYhGtvSjlN5E=','2021-10-06 11:08:54.575108',1,'admin','','','',1,1,'2021-09-25 16:16:53.037901','123','onair','',''),('',NULL,0,'ji woo park','','','jiu.1997.park@gmail.com',0,1,'2021-09-29 13:06:07.794419','35oCSujn3gZZF','지우','https://lh3.googleusercontent.com/a-/AOh14Gigwod9hV7dZbNVp0nL5VBZfTraQfyUjMGRbZ1TVA=s96-c','115640442315789597924'),('',NULL,0,'Jeon SunGyu','','','sungyujeon91@gmail.com',0,1,'2021-10-06 15:33:57.533724','9bkug5PVLyTp3','Jeon SunGyu','https://lh3.googleusercontent.com/a/AATXAJx7kvsa9CtibFFuo3Ykb8NoM4N1hjl55m03d6lx=s96-c','106078515773569537297'),('',NULL,0,'나승호','','','seungho.dev28@gmail.com',0,1,'2021-10-04 00:09:56.891785','hY3mE9jOg2SDz','나승호','https://lh3.googleusercontent.com/a/AATXAJw2zQWJ6oPu6dc84kIXoC8368fv4RJ5J8Z9W8IL=s96-c','106495574079791876612'),('',NULL,0,'[서울_3반_김호영]','','','h01097645002@gmail.com',0,1,'2021-10-04 22:07:39.657646','ioy6m8BoYsLQ3','[서울_3반_김호영]','https://lh3.googleusercontent.com/a/AATXAJwzE1-bmPBN7SGQExD9YSuFMMrL_gENrcmGGCWn=s96-c','114584368387009040120'),('',NULL,0,'승호','','','qlfflwls2@gmail.com',0,1,'2021-10-01 09:54:44.535774','J30ilvYaTleBb','나승호','https://lh3.googleusercontent.com/a/AATXAJzRLWWbwUeEJfAAUwiwzKrc62z_RXcDW8ND2LSH=s96-c','115085252102762834259'),('',NULL,0,'한상진','','','gkstkdwls1994@gmail.com',0,1,'2021-09-29 13:01:09.073932','tK5lakjP6KssR','한상진','https://lh3.googleusercontent.com/a-/AOh14GjeG-Pssv2_zwY1B9kpDn4G54Tmjbb0--NsS8WH=s96-c','101023598295427317906'),('',NULL,0,'이현정','','','dlguswjd0258@gmail.com',0,1,'2021-09-29 13:37:41.333533','uaR3L5im3X1Pl','이현정','https://lh3.googleusercontent.com/a/AATXAJwhnHi2AH84rDRMxN0SQPolkq4n5LaGj1QqPF-g=s96-c','105854022862422459657'),('',NULL,0,'HU K','','','hyeonuk27@gmail.com',0,1,'2021-09-29 12:52:01.476748','UidJSNc8AxEHK','HU K','https://lh3.googleusercontent.com/a-/AOh14GhbJUOewOwAQQCBoJvNfduFKVH64UVU8RPaa5kT0A=s96-c','101303973595319045713'),('',NULL,0,'안수빈','','','axsxbxx@gmail.com',0,1,'2021-10-01 22:29:06.548108','Un65hnQdIn4U9','axxsxbxx','https://lh3.googleusercontent.com/a/AATXAJwCA5kdW1j1H-XSOWDbXC007kNEK_nEwl4RQGY8=s96-c','106419790997353454728'),('',NULL,0,'subin ahn','','','ansubin2004@gmail.com',0,1,'2021-09-26 15:31:58.301487','vWH12hUs7iSaR','subin','https://lh3.googleusercontent.com/a/AATXAJwdbJ3bF-juzeGT3rfWRgrSpEa5HDnNRVn9ncAx=s96-c','110179110285642599560'),('',NULL,0,'CHENNI','','','chenni0531@gmail.com',0,1,'2021-10-06 17:58:35.895727','X0X6uCJkRB44p','CHENNI','https://lh3.googleusercontent.com/a-/AOh14GjaFdeCCsps9a3v_LLlHT55h3SdE7A93NW7XHo1tA=s96-c','110274406059954003386');
/*!40000 ALTER TABLE `accounts_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-07 10:25:56
