-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: j5a203.p.ssafy.io    Database: OnAir
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airlines_airline`
--

DROP TABLE IF EXISTS `airlines_airline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airlines_airline` (
  `id` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone_number` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `site_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `corona_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_skyteam` tinyint(1) DEFAULT NULL,
  `is_star` tinyint(1) DEFAULT NULL,
  `is_oneworld` tinyint(1) DEFAULT NULL,
  `total_canceled` int NOT NULL,
  `total_delayed` int NOT NULL,
  `total_flight` int NOT NULL,
  `detail` longtext COLLATE utf8mb4_general_ci NOT NULL DEFAULT (_utf8mb3'detail'),
  `over_60` int NOT NULL,
  `under_30` int NOT NULL,
  `under_60` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airlines_airline`
--

LOCK TABLES `airlines_airline` WRITE;
/*!40000 ALTER TABLE `airlines_airline` DISABLE KEYS */;
INSERT INTO `airlines_airline` VALUES ('0UnsY76Y2FJFr','유나이티드항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/united_airlines.png','233 S. Wacker Drive, 시카고, IL 60606','+1 800-864-8331','http://www.united.com/','https://www.united.com/ual/en/us/fly/travel/notices.html',0,1,0,8,111,1574,'유나이티드 항공(UA)은 미국에 거점을 둔 항공사이며 취항도시 수로 세계 최대의 항공사이다. 유나이티드 항공은 스타 얼라이언스 회원사로 미국 국내 75개 도시를 포함한 북미와 남미, 유럽, 아시아, 아프리카 및 오세아니아 지역 70개국 375여개 공항에서 직행편을 운영하고 있다. 기내 좌석 등급이 2가지, 3가지 및 4가지 있는 항공편이 있으며, 좌석 종류는 퍼스트 클래스(국제선에서 글로벌 퍼스트, 국내선에서 유나이티드 퍼스트라 불린다) , 비즈니스 클래스(비즈니스 퍼스트 혹은 유나이티드 비즈니스), 몇가지 대륙횡단편에 있는 유나이티드 피에스(프리미엄 서비스의 준말), 이코노미 플러스 클래스 및 이코노미 클래스가 있다. 프리미엄 캐빈 이용고객은 40여개 공항에 마련된 유나이티드 클럽 라운지를 이용할 수 있다.',102,1455,9),('1vSpSCa8BfXHh','아시아나항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/asiana_airlines.png','No 47 Osae-Dong, Gangseo-gu, 서울 157-713','02-2669-8000','https://flyasiana.com/C/US/KO/index','https://flyasiana.com/C/US/KO/contents/stay-safe-with-oz',0,1,0,93,8974,95717,'아시아나항공은 대한민국의 민간 항공사이자 대한항공에 이은 대한민국 2위 규모의 민간 항공사로 인천국제공항과 김포국제공항을 허브 공항으로 하고 있으며, 항공 동맹체인 스타얼라이언스의 가맹사이다.',8390,86677,557),('81aokx0yfiDMn','아메리칸항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/american_airlines.png','4333 Amon Carter Boulevard, 포트 워스, TX 76155-2605','+1 800-433-7300','https://www.aa.com/','https://www.aa.com/i18n/travel-info/coronavirus-updates.jsp',0,0,1,3,71,1346,'텍사스의 포트 워스에 본부를 두고 있는 아메리카 항공(AA)은 북미, 남미, 카리브 해 그리고 아시아의 40여개가 넘는 국가의 250여개가 넘는 곳으로 취항합니다. 시카고 오헤어 국제공항(ORD), 런던 히스로 공항(LHR), 뉴욕 존 F 케네디 공항(JFK), 마이애미 국제공항(MIA) 그리고 로스 엔젤레스 국제공항(LAX)을 허브로 하여 AA는 매일 6,700회가 넘는 편을 운항합니다. 전세계 약 50개의 어드마이럴스 클럽 라운지를 비롯하여 이 항공사는 JFK, LAX, LHR 그리고 ORD에서 국제 및 대륙간을 이동하는 편을 이용하는 퍼스트 클래스 여객을 위한 4개의 플래그십 라운지를 가지고 있습니다.',68,1272,3),('BA7rTNyElww1S','중국동방항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/chinese_eastern.png','2nd Floor Citibank Tower, No. 33 Shanghai Huayuanshiqiao Road, 상하이 중국 201202','+86 95530','http://www.flychinaeastern.com/','https://us.ceair.com/en/',1,0,0,42,1846,17676,'상하이 홍차오 국제공항에 (SHA) 기반을 둔 차이나 이스턴 에어라인은 (MU) 아시아, 유럽, 오세아니아, 아프리카 그리고 북미를 가로지르는 200여 개의 지역, 국내 그리고 국제선을 제공합니다. 스카이팀 얼라이언스의 구성원인 이 항공사는 중국에서 두 번째로 큰 승객 항공사입니다. 이 항공사는 이코노미 클래스로만 있는 항공기, 객실이 두 개 있는 항공기 (비즈니스 클래스와 이코노미 클래스) 그리고 객실 세 개의 항공기를 (퍼스트 클래스, 비즈니스 클래스 그리고 이코노미 클래스) 보유하고 있습니다. 차이나 이스턴은 상하이 푸동 국제공항 (PVG), 시안 셴양 국제공항 (XIY) 그리고 쿤밍 창슈이 국제공항을 (KMG) 거점으로 합니다.\n',1775,15790,69),('dBlZyn2PT5qGh','독일항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/german_airlines.png','Von-Gablenz- Strasse 2-6, 쾰른 노스라인-웨스트팔리아 독일 50679','+49 69 86799799','http://www.lufthansa.com/','https://www.lufthansa.com/xx/en/flight-information.html',0,1,0,4,204,2203,'유럽에서 가장 큰 항공사로 프랑크푸르트에 본사를 둔 루프트한자(LH)는 약 215개 도시로 직항 노선을 운항합니다. 이 운항지에는 독일 국내 18개 지역 및 유럽, 아프리카, 아시아, 호주, 중동, 북아메리카, 카리브해 지역, 남아메리카에 있는 78개국이 포함됩니다. 이 항공사는 단일 클래스부터, 퍼스트 클래스, 비즈니스 클래스, 프리미엄 이코노미 클래스, 이코노미 클래스가 있는 4종 클래스까지 다양한 구성의 항공기를 보유하고 있습니다. 스타 얼라이언스 멤버인 루프트한자는 5개 다른 항공사화 코드 셰어 협정도 맺고 있습니다. 또한 오스트리아 항공, 스위스 국제항공, 에어 돌로미티, 루프트한자 시티라인, 저먼윙스 등을 포함하는 다수의 자회사도 보유하고 있습니다. 이 항공사는 프랑크푸르트 공항(FRA)과 뮌헨 국제공항(MUC)에 허브가 있습니다.\n',196,1995,8),('eNBmkioknGKbZ','네덜란드항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/klm.png','Amsterdamseweg 55, 암스텔펜 네덜란드 1182 GP','+31 20 474 7747','http://www.klm.com/','https://www.klm.com/travel/us_en/prepare_for_travel/up_to_date/flight_update/index.htm',1,0,0,0,21,1515,'네덜란드 대표 항공사인 KLM(KL)은 스히폴 공항(AMS)에 있는 항공사 허브와 가까운 암스텔베인에 본사를 두고 있습니다. 스카이 팀 제휴 멤버인 KLM은 70여 개국 130여 개 도시로 직항 노선을 운항합니다. 운항지에는 유럽 지역뿐 아니라 아프리카, 아시아, 호주, 카리브해 지역, 중동, 북아메리카, 남아메리카 도시들이 포함됩니다. 보유 항공기는 비즈니스 클래스, 이코노미 컴포트 클래스, 이코노미 클래스의 3종 클래스로 구성되어 있습니다. 장거리 항공편의 경우, 비즈니스 클래스(월드 비즈니스 클래스로 알려짐)의 수평으로 펴지는 좌석(lie-flat)이 특징입니다.',21,1494,0),('k1EkCyeNOqzkz','대한항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/koreanair.png','Korean Air Operations Center, 1370 Gonghang-Dong, 서울 157712','1588-2001','http://www.koreanair.com/','https://www.koreanair.com/global/en/about/news/travel_info/2020_03_covid/',1,0,0,151,9807,135419,'대한민국 대표 항공사이므로 대한항공(KE)은 한국에서 가장 큰 항공사입니다. 서울에 본사를 둔 이 항공사는 국내 20개 도시와 아시아, 호주, 아프리카, 유럽, 북아메리카, 남아메리카에 걸친 100여 개의 국제적인 도시로 운항하고 있습니다. 또한 스카이팀 제휴 멤버인 이 항공사는 40여 개 항공사와 코드 셰어 협정을 맺고 있습니다. 보유 항공기들은 2종 클래스 항공기(비즈니스 클래스의 한 버전인 프레스티지 클래스, 이코노미 클래스)와 3종 클래스 항공기(퍼스트 클래스, 프레스티지 클래스, 이코노미 클래스)로 구성되어 있습니다. 대한항공은 서울 김포국제공항(GMP)과 서울 인천국제공항(ICN)에 허브가 있습니다.',8114,125605,1549),('kFLMeliwqBJsP','진에어','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/jin_air.png','453, Gonghang-daero, Gangseo-gu, 서울 157-841','1600-6200','http://www.jinair.com/','https://www.jinair.com/company/announce/announceView?anceSeq=21258&searchWord=&searchKey=&page=1',0,0,0,42,2082,33161,'진에어는 대한항공이 출자한 대한민국의 저비용 항공사로 대한민국의 운송 전문 기업집단인 한진그룹에 소속되어 있으며 2017년 12월 8일 코스피에 상장되었다.',135,31040,101),('KzeKUwhS7wGRA','프랑스항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/air_france.png','45 rue de Paris, Roissy-en-France 프랑스 95 747','+33 3654','http://www.airfrance.com/','https://www.airfrance.us/US/en/common/page_flottante/hp/news-air-traffic-air-france.htm?_ga=2.8073783.483960263.1584621588-331937894.1584621588',1,0,0,2,141,1485,'에어프랑스(AF)는 프랑스를 대표하는 프랑스 최대의 항공사입니다. 스카이팀 얼라이언스의 창립 멤버이며 프랑스 내 35개, 93개 국가 약 170개 취항지로 항공편을 운항합니다. 유럽 전역과 아시아, 아프리카, 북아메리카, 남아메리카 직항 노선을 이용할 수 있습니다. 장거리 국제선 항공편은 일반적으로 세 가지 또는 네 가지 클래스의 서비스를 제공합니다. 유럽 내 단거리 및 중거리 항공편은 3개 객실로 구성되어 있습니다. 에어프랑스는 샤를드골 국제공항(CDG)과 오를리 공항(ORY)을 허브 공항으로 이용합니다.\n',1978,1342,6),('NA8QShMTtLEj6','중국남방항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/chinese_southern.png','278 Jichang Road, 광저우 중국 510405','+86 95539','http://www.csair.com/','https://global.csair.com/',1,0,0,34,915,18417,'세계에서 6번째로 큰 차이나 써던 에어라인은 (CZ) 중국, 아시아, 유럽, 오세아니아 그리고 북미를 가로지르는 190여 개의 목적지에 직항기를 운항합니다. 총 35개의 국가를 운항합니다. 스카이팀 얼라이언스의 구성원인 이 항공사의 거점은 광저우 바이윈 국제공항 (CAN) 입니다. 이차 거점은 충칭 장베이 국제공항 (CKG), 베이징 수도 국제공항 (PEK) 그리고 우루무치 디워프 국제공항 (URC) 입니다. 차이나 써던은 퍼스트 클래스, 비즈니스 클래스, 프리미엄 이코노미 클래스 그리고 이코노미 클래스를 포함한 다양한 구성의 항공기를 가지고 있습니다.\n',880,17472,31),('Ni9M0YKqOJI6o','델타항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/delta.png','1030 Delta Blvd, 애틀랜타, GA 30354','+1 800-221-1212','https://www.delta.com/','https://www.delta.com/us/en/coronavirus-update-center/overview?Log=1&mkcpgn=sezzzggusabspribd&clickid=_k_CjwKCAjwsMzzBRACEiwAx4lLGygzDI5b8sjmc1HQZ4Jyiy5DVmqwQyPpC1Idei5gkgxSnJxcLfqtzRoCJYAQAvD_BwE_k_&tracking_id=284x10598556&ad_id=425479292874&s_kwcid=TC%7Cdelta%7C%7CS%7Ce%7C425479292874&campaign=9617149371&adgroup=99126258916&gclid=CjwKCAjwsMzzBRACEiwAx4lLGygzDI5b8sjmc1HQZ4Jyiy5DVmqwQyPpC1Idei5gkgxSnJxcLfqtzRoCJYAQAvD_BwE',1,0,0,7,197,4383,'델타 항공은 미국의 항공사이다. 본사는 조지아주 애틀랜타에 있으며, 총 여객 운송수, 보유 항공기수, 연간 매출액을 기준으로 세계 최대의 항공사로 꼽힌다. 또한 미국의 메이저 항공사중 하나이다.',190,4179,7),('oPWk1Er8anSzE','에미레이트항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/emirates.png','PO Box 686, 두바이 아랍에미리트','+971 600 555555','http://www.emirates.com/','https://www.emirates.com/us/english/help/travel-updates/#3515',0,0,0,1,15,1573,'아랍 에미리트 연합국에 기반을 둔 에미리트는 (EK) 중동에서 가장 큰 항공사로 이 나라의 2개의 국적기 중 하나입니다. 에미리트는 두바이 국제공항을 (DXB) 거점으로 78개국 140개 이상의 지역에 직항기를 운항합니다. 이 항공사는 6대륙을 운항하는 몇 안 되는 항공사입니다. 에미리트의 항공기는 객실 세 개 구성 (퍼스트 클래스, 비즈니스 클래스 그리고 이코노미 클래스) 위주로 몇몇 객실 두 개로 (비즈니스 클래스 그리고 이코노미 클래스) 구성되어 있습니다. 퍼스트 클래스에는 특실, 평평한 침대와 침대 겸용 좌석을 포함해 몇가지 종류의 좌석이 있습니다. 에미리트는 퍼스트 클래스, 비즈니스 클래스 승객 그리고 스카이워드 골드 회원을 위한 33개 에미리트 라운지를 운영합니다.\n',15,1557,0),('Q3kblAER0jeSX','티웨이항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/tway.png','Seongdong-0169, Haneul-gil, Gangseo-gu, 서울','1688-8686','https://www.twayair.com/','https://www.twayair.com/app/customerCenter/notice',0,0,0,34,2136,25179,'티웨이항공은 대한민국의 저비용항공사이다. 현재 국내선은 김포-제주, 대구-제주, 무안-제주, 광주-제주 노선을 운항 중이며 국제선은 김포-타이베이, 대구-타이베이, 대구-블라디보스토크를 비롯한 여러 노선을 운항 중이다.',2071,23010,64),('QMjOIYCia5in3','제주항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/jejuair.png','312-1 Yon-Dong, 제주 63000','1599-1500','http://www.jejuair.net/','https://www.jejuair.net/jejuair/kr/event/safeHealthy.do',0,0,0,60,3387,48856,'제주항공(7C)은 본사가 제주시에 있는 대한민국 항공사입니다. 인천국제공항(ICN)과 제주국제공항(CJU)를 주요 거점으로, 김해국제공항(PUS)을 보조 허브로 운영하고 있습니다. 국내에서는 6개 도시로 운항하고 있습니다. 또한 캄보디아, 괌, 홍콩, 일본, 북 마리아나 제도, 중국, 필리핀, 대만, 태국, 베트남으로의 정기적인 국제노선뿐 아니라 전세항공도 제공합니다. 제주항공은 이코노미 클래스로만 구성된 보잉 737-800 20기를 보유하고 있습니다.\n',3235,45411,150),('SFFiToPBXR7BC','에어서울','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/air_seoul.png','76, SaemunanRo Jongro Gu, 서울','1800-8100','https://flyairseoul.com/','https://flyairseoul.com/CW/en/noticeList.do',0,0,0,15,822,13264,'에어서울은 대한민국의 6번째 저비용항공사이자 아시아나항공이 출자한 두 번째 저비용 항공사이다.',789,12428,32),('Tc5tKZvNDQ77E','카타르항공','https://j5a203.p.ssafy.io/static/airlines/images/airline_logo/qatar_airways.png','Qatar Airways Tower Airport Road, 도하 카타르','+974 4023 0000','http://www.qatarairways.com/','https://www.qatarairways.com/en/travel-alerts/COVID-19-update.html',0,0,1,1,26,1785,'카타르항공(QR)은 카타르의 국적항공사이며 원월드 얼라이언스의 회원사입니다. 하마드 국제공항(DOH)을 허브로, 6개 대륙 전역에 걸친 145개 취항지에 항공편을 제공합니다. 카타르항공의 항공기는 투-캐빈(비즈니스 클래스와 이코노미 클래스), 쓰리-캐빈(퍼스트 클래스, 비즈니스 클래스, 이코노미 클래스)로 구성돼있습니다. 비즈니스 클래스와 퍼스트 클래스 좌석 모두 침대로 전환할 수 있습니다. 하마드 국제공항에서 탑승한 프리미엄 클래스 승객을 위해, 항공사는 알무르잔 비즈니스 라운지를 운영합니다. 두 번째 카타르항공 라운지는 런던 히드로 공항(LHR)에서 만날 수 있습니다.',25,1758,1);
/*!40000 ALTER TABLE `airlines_airline` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-07 10:25:56
