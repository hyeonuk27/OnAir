-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: j5a203.p.ssafy.io    Database: OnAir
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airlines_arrival`
--

DROP TABLE IF EXISTS `airlines_arrival`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `airlines_arrival` (
  `id` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airlines_arrival`
--

LOCK TABLES `airlines_arrival` WRITE;
/*!40000 ALTER TABLE `airlines_arrival` DISABLE KEYS */;
INSERT INTO `airlines_arrival` VALUES ('136hnjTd4q7NY','LAS(라스베이거스)'),('1B60PsvwlP2RE','ATL(애틀랜타)'),('1huJy9Zg80bgf','AKL(오클랜드)'),('1XUFwW0Lugfkw','RMQ(타이중)'),('23XDJnK3LIY1u','WUH(우한)'),('2b8ddc208SBCC','DOH(도하)'),('2sOOGaLhangVb','HRB(하얼빈)'),('3WLv22yDUUhtC','HKT(푸켓)'),('4TdQNae8ObtVo','VIE(빈)'),('5AbdwHIx7u5Z6','IST(아타튀르크)'),('65c4iKleagwvN','SPN(사이판)'),('6FsrzfgvajGgz','DFW(댈러스)'),('6uH2xIwaX32jw','MUC(뮌헨)'),('7bZIblT2iCmu5','YYZ(토론토)'),('8gtwJ4r4Hp0xi','KMI(미야자키)'),('8y2bkAt8iUYiT','NGO(나고야)'),('a1itzEJnWqblH','KUL(쿠알라룸푸르)'),('a1m2Nlu9pMuCe','TAK(다카마쓰)'),('arD7ib0m3iZvN','FCO(로마)'),('BAf8ozHGQ9Phq','ORD(시카고)'),('bFtJXFYYzy3pM','SYD(시드니)'),('BsnETVvVtI22R','SGN(떤선녓(호치민))'),('BXXEPdourahdE','MFM(마카오)'),('c0udOKpdYmR2F','VTE(비엔티안)'),('C5EOLRJqC55zP','YVR(밴쿠버)'),('C93KjIc6mSsyV','TPE(타이완 타오위안 국제 공항)'),('cahFYhypcLlLi','CDG(파리)'),('cKsuP8ngBBOC1','CXR(깜라인(냐짱))'),('CxwELTrOei0YU','HNL(호놀룰루)'),('dofm07d3gAGbu','YNZ(옌청)'),('edpWR4kHMMEQG','AMS(암스테르담)'),('enAy5Cq5PbPbJ','BNE(브리즈번)'),('F7GlED6ok9MSP','SDJ(센다이)'),('FBOcUFV0WFm0C','HAK(하이커우)'),('FbzQZCzHmIaZV','MAD(마드리드)'),('FGduwxuUZchtO','AOJ(아오모리)'),('fjdnAHOmTMcqN','KIX(간사이)'),('FYCKlh4xjBvSA','JHB(조호르바루)'),('g0yiWcxdfoYw7','TAS(타슈켄트)'),('g5Gie9vDC8u4B','HFE(허페이)'),('GC4kuOWIOMXZU','DTW(디트로이트)'),('gIfhLvhZLyiEN','CGQ(장춘)'),('h69kbPyCxZOXc','XMN(샤먼)'),('HabuHviIJ5jNe','CNX(치앙마이)'),('HCr7SSU8gc5tS','SIN(싱가포르)'),('HXFybRAXkonYe','CGK(자카르타(수카르노 하타) 국제 공항)'),('IAYJ0jRDcVt7s','CGO(정저우)'),('IbiMSep6K9u0b','HAN(노이바이(하노이))'),('IDOoeGU2eclMM','SHE(심양)'),('IJvj7BmnN3OTz','BKI(코타키나발루)'),('iYVxJSwlYH1QC','KTM(카트만두)'),('J2hissKBx3yT8','XIY(시안)'),('Jjac79awMYirE','VVO(블라디보스톡)'),('jQThIiivFp2Ly','TAO(청도)'),('jyqJWvOvqKucY','CAN(광저우)'),('k8AveKCPhsTYx','RGN(양곤)'),('kGFg4Fv2ox5mk','CEB(세부)'),('Kics5FVUt15jj','OIT(오이타)'),('l5YvkJtoqVlqc','BOM(뭄바이)'),('lbm5m782k6VzH','ROR(코로르)'),('lIpVG6iv0zZrU','KOJ(가고시마)'),('LtfdiCD02x0t4','BCN(바르셀로나)'),('lXQUt9Rz1ZFeV','DPS(덴파사(응우라 라이))'),('lxTXX23G72d5v','PRG(프라하)'),('mdvl2tPOQN1RD','BKK(수완나품(방콕))'),('mLSV8mQVP24C2','JFK(뉴욕)'),('myWp1sLA8S1BJ','TSN(톈진)'),('NcVZM6Gu8hXAK','FSZ(시즈오카)'),('NGNcJtGkb9S8y','DLC(대련)'),('Nl04rUFXbVw00','PUS(김해)'),('O5tWztYGfArsM','CRK(클라크 국제공항)'),('oa9JWiJEz2CF6','KLO(칼리보)'),('ON8XXXnoWXsPP','CTS(삿포로)'),('oNKb3v2OEUXVd','LAX(로스앤젤레스)'),('onlgfRrL0Pu4b','REP(씨엠립)'),('puj04a9xvBfRe','DAD(다낭)'),('q1PQg1XCoOyHl','MNL(마닐라)'),('q7a1pL0EPCJls','HKG(홍콩)'),('qbrmB1TuWL4Xx','KIJ(니가타)'),('QNehVHbXz6oJp','HIJ(히로시마)'),('qR8kcZEp3xqzw','YGJ(요나고)'),('R8hXVjoVwsrIS','TAE(대구)'),('Rc8m6M9POMjaV','OKA(오키나와)'),('Rcow8jQAmcZlP','PEK(베이징)'),('rHJvZQvJu1VS4','SEA(시애틀)'),('RNFOKnDNiLdFf','IAD(워싱턴)'),('rowWAuW2FbbHH','DEL(델리)'),('rQIQNH0HEE0oZ','WEH(위해)'),('RyQXqxfPkz7ZA','HND(하네다)'),('s6HpOjiUWi8wb','SVO(셰레메티예보(모스크바))'),('SUqA5ypXZ5H5s','MXP(밀라노)'),('teC1iNMd2Mwzd','KKJ(기타큐슈)'),('teOJXXXc5U9uK','CTU(청두(성도))'),('TesmZsxPqpqNs','SZX(선전(심천))'),('tJQRxHnK5NI53','PNH(프놈펜)'),('TvnPeCtayfBgH','NKG(남경)'),('UmE24GZzuSbBP','YNJ(연길)'),('UrFnRwfTzkzcL','MDG(목단강)'),('vbC8iV9eZKAFG','GUM(괌)'),('VbLT3h71YiTyB','LHR(런던히드로)'),('vJhvqrbNafIYh','FRA(프랑크푸르트)'),('VS3whcqkLw46j','CSX(창사(장사))'),('vscM9lxPZeTfi','ULN(보얀트 오하(울란바토르))'),('wmDeILbmuJFIf','PVG(푸동)'),('WMdPaT5aOPnGH','FUK(후쿠오카)'),('wspI0OD5xk0PQ','KMJ(구마모토)'),('x3pbIvZ8xX9WM','ALA(알마티)'),('x5AWo3XyPC8DA','NRT(나리타)'),('X9Yi5ZMxDY3zd','KWL(계림)'),('xhO2njrOLIle3','OKJ(오카야마)'),('xwGqTmiHK1r9j','SYX(싼야)'),('yIcKAUngEHIYx','CKG(충칭)'),('yQQYvxYiuC8fr','KMG(쿤밍)'),('Z3XAPpbJ7Pdyx','YNT(연태)'),('zB2NWMIdHrTj7','DXB(두바이)'),('ztZzJlor3aImq','KHH(가오슝)'),('Zu7Mx5KdfLy0F','HGH(항저우)'),('zUo8HvZ9xnr6i','SFO(샌프란시스코)'),('ZWTsSmXdRHNeQ','HSG(사가)'),('ZZ7z6AaZ8MfEG','TNA(지난)');
/*!40000 ALTER TABLE `airlines_arrival` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-07 10:25:59
